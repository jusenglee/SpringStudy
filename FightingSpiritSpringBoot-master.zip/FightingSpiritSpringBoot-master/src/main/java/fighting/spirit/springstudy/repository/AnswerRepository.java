package fighting.spirit.springstudy.repository;

import fighting.spirit.springstudy.entity.AnswerEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AnswerRepository extends JpaRepository<AnswerEntity, Integer> {

}
