package fighting.spirit.springstudy.form;

import lombok.Data;

@Data
public class SearchForm {
    private String academic;
    private String career;
    private String area;
}
